/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package av3;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author WesleyReis
 */
public class Arquivo {

    public Arquivo() {
        try{
           FileOutputStream a = new FileOutputStream("contatos.txt", true);
           a.close();
        }catch(Exception ex){
            
        }
    }
    
    
    public void salvar(ArrayList<Contato> array) {
        FileOutputStream fout;
        ObjectOutputStream out;
        try {
            fout = new FileOutputStream("contatos.txt");
            out = new ObjectOutputStream(fout);

            out.writeObject(array);

            out.close();
            fout.close();
            System.out.println("deu certo");
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println(ex);
        }
    }

    public ArrayList<Contato> ler() {
        FileInputStream fin;
        ObjectInputStream in;
        ArrayList<Contato> contato = new ArrayList<>();

        try {
            fin = new FileInputStream("contatos.txt");
            in = new ObjectInputStream(fin);

            contato = (ArrayList<Contato>) in.readObject();

            in.close();
            fin.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
        return contato;
    }

}
