/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package av3;

import java.io.Serializable;

/**
 *
 * @author WesleyReis
 */
public class Contato implements Serializable, Comparable<Contato>{
    
    
    private String nome;
    private String sobrenome;
    private String endereco;
    private String telefone;

    @Override
    public String toString() {
        return "Nome: " + nome + " Sobrenome: " + sobrenome + " Endereço: " + endereco + " Telefone: " + telefone;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    @Override
    public int compareTo(Contato o) {
        return nome.compareTo(o.getNome());
    }


    
    
    
    
}
