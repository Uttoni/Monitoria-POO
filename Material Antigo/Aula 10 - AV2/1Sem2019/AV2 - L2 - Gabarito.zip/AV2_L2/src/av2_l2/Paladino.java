package av2_l2;

/**
 * Classe Paladino, que é filha de Personagem, implementa as interfaces DanoEmAlvo e DanoEmArea
 * @author Samuel
 */
public class Paladino extends Personagem implements DanoEmAlvo, DanoEmArea{

    // Atributos
    private int defEscudo;
    private boolean montaria;
    
    // Método específico de Paladino
    public void encantarArma(){
        System.out.println("Encantando a " +  arma.getTipo() + " !!");
    }
    
    // Métodos da Interface
    @Override
    public void usarArma() {
        System.out.println("Atacando fisicamente com " + arma.getTipo() + " !!");
    }

    @Override
    public void usarMagia() {
        System.out.println("Atacando com magias !!");
    }
    
    // Sobrescrevendo o método infoPersonagem
    @Override
    public void infoPersonagem(){
        // Chamando o método já criado na classe mãe para poupar código
        super.infoPersonagem();
        // Incrementando informações com os atributos da classe
        System.out.println("Defesa do Escudo: " + this.defEscudo);
        System.out.println("Possui montaria? " + this.montaria);
    }
    
    // Getters e Setters
    public int getDefEscudo() {
        return defEscudo;
    }

    public void setDefEscudo(int defEscudo) {
        this.defEscudo = defEscudo;
    }

    public boolean isMontaria() {
        return montaria;
    }

    public void setMontaria(boolean montaria) {
        this.montaria = montaria;
    }
    
}
