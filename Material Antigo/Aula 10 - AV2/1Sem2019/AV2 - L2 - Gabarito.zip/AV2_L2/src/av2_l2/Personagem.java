package av2_l2;

/**
 * Classe mãe
 * @author Samuel
 */
public abstract class Personagem {
    
    // Contador
    public static int contador;
    
    // Atributos
    protected String nome;
    protected int HP;
    protected int SP;
    protected int nivel;
    
    // Não se deve instanciar esta classe no construtor, pois a classe Personagem é abstrata
    // Portanto não vamos instancia-la e consequentemente não vamos chamar o construtor !
    protected Arma arma = new Arma();
    
    // Métodos
    public void usarPocao(){
        // Curando a vida (HP)
        System.out.println("Usando poção ... ");
        this.HP += 50;
    }
    
    public void uparNivel(){
        // Incrementando um nível
        System.out.println("Subindo de nivel !!");
        this.nivel += 1;
    }
    
    public void infoPersonagem(){
        // Escrevendo o método mostraInfo para poupar código nas classes filhas
        System.out.println("Nome: " + this.nome);
        System.out.println("HP: " + this.HP);
        System.out.println("SP: " + this.SP);
        System.out.println("Nivel do Personagem: " + this.nivel);
        System.out.println("Tipo da Arma: " +  this.arma.getTipo());
        System.out.println("Numero de mãos da arma: " + this.arma.getNumMaos());
        System.out.println("Ataque da Arma: " + this.arma.getAtaque());
    }
}
