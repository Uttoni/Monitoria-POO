package av2_l2;

/**
 * Classe Arquimago, filha de Personagem, que implementa o método DanoEmArea
 * @author Samuel
 */
public class Arquimago extends Personagem implements DanoEmArea{
    
    // Atributos
    private String elemento;
    private int numMagias;
    
    // Método específico da classe
    public void protecaoArcana(){
        System.out.println("Castando Proteção Arcana !!");
    }

    // Método da Interface
    @Override
    public void usarMagia() {
        System.out.println("Usando magia em área do elemento " + this.elemento + " !!");
    }
    
    // Sobrescrevendo o metodo info
    @Override
    public void infoPersonagem(){
        // Chamando o método já pronto da classe mãe para poupar código
        super.infoPersonagem();
        // Incrementando o metodo com os atributos de Arquimago
        System.out.println("Elemento: " + this.elemento);
        System.out.println("Número de Magias aprendidas: " + this.numMagias);
    }
    
    // Getters e Setters 
    public String getElemento() {
        return elemento;
    }

    public void setElemento(String elemento) {
        this.elemento = elemento;
    }

    public int getNumMagias() {
        return numMagias;
    }

    public void setNumMagias(int numMagias) {
        this.numMagias = numMagias;
    }
    
    
}
