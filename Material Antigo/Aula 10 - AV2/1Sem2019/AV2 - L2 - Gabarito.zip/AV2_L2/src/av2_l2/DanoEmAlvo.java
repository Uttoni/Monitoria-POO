package av2_l2;

/**
 * Interface contendo o método abstrato usarArma
 * @author Samuel
 */
public interface DanoEmAlvo {
    
    public void usarArma();
    
}
