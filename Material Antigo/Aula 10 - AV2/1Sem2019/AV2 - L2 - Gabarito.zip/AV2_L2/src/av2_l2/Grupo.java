package av2_l2;

/**
 *
 * @author Samuel
 */
public class Grupo {

    // Array de Personagens, com tamanho pré-definido
    private Personagem[] cla = new Personagem[10];

    // Método para adicionar Personagens no array
    public void addPersonagem(Personagem novoPersonagem) {
        // Percorre o array 
        for (int i = 0; i < cla.length; i++) {
            // Verifica se a posição está vazia (null)
            if (cla[i] == null) {
                // Se estiver armazena o Personagem no array
                cla[i] = novoPersonagem;
                // Incremento no contador
                Personagem.contador++;

                // Necessário para sair do for !! Se já salvou no array não tem por que continuar percorrendo o array.
                // Caso não use o break, você irá preencher completamente o array com o objeto novoPersonagem!!
                break;
            }
        }
    }

    // Listagem de Personagens
    public void listarPersonagens() {
        // Percorre o array
        for (Personagem personagem : cla) {
            // Verifica qual classe está armazenada naquela posição
            if (personagem instanceof Arquimago) {
                // Se for arquimago cai aqui

                // Criando uma variável Auxiliar e Fazendo o Casting
                Arquimago mago = (Arquimago) personagem;

                // Chamando os métodos
                mago.usarPocao();
                mago.uparNivel();
                mago.protecaoArcana();
                mago.usarMagia();
                // Por ultimo o infoPersonagem
                mago.infoPersonagem();
                
                System.out.println("********************");
            }
            
            // Para Paladino
            if (personagem instanceof Paladino) {
                Paladino pala = (Paladino) personagem;

                pala.usarPocao();
                pala.uparNivel();
                pala.encantarArma();
                pala.usarMagia();
                pala.usarArma();
                
                pala.infoPersonagem();
                
                System.out.println("********************");
            }
            
            // Para Algoz
            if (personagem instanceof Algoz) {
                Algoz mercenario = (Algoz) personagem;
                
                mercenario.usarPocao();
                mercenario.uparNivel();
                mercenario.furtividade();
                mercenario.usarArma();
                
                mercenario.infoPersonagem();
                
                System.out.println("********************");
            }
            
            // Pala Justiceiro
            if ( personagem instanceof Justiceiro ) {
                Justiceiro guns = (Justiceiro) personagem;
                
                guns.usarPocao();
                guns.uparNivel();
                guns.rastrearAlvo();
                guns.usarArma();
                
                guns.infoPersonagem();
                
                System.out.println("********************");
            }
        }
        // Mostra o número final de personagens salvo no array
        System.out.println("Total de Personagens: " + Personagem.contador);
    }
}
