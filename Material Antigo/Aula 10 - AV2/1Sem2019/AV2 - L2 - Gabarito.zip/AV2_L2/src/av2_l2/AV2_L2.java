package av2_l2;

/**
 * Classe Princial
 *
 * @author Samuel
 */
public class AV2_L2 {

    public static void main(String[] args) {

        // *** Criando os personagens e atribuindo valores ***
        // Arquimago
        Arquimago hw = new Arquimago(); /* Criando um Objeto do tipo Arquimago */
        hw.nome = "Warlock";            /* Atributos da Classe Mãe (Herdados) */
        hw.HP = 200;                    /* Atributos da Classe Mãe (Herdados) */
        hw.SP = 50;                     /* Atributos da Classe Mãe (Herdados) */
        hw.nivel = 98;                  /* Atributos da Classe Mãe (Herdados) */
        hw.arma.setAtaque(20);          /* Atributos da Arma do Arquimago */
        hw.arma.setNumMaos(2);          /* Atributos da Arma do Arquimago */
        hw.arma.setTipo("Cajado");      /* Atributos da Arma do Arquimago */
        hw.setElemento("Fogo");         /* Atributos da Classe Arquimago */
        hw.setNumMagias(5);             /* Atributos da Classe Arquimago */

        // Paladino
        Paladino rg = new Paladino();
        rg.nome = "Royal Guard";
        rg.nivel = 50;
        rg.HP = 1000;
        rg.SP = 50;
        rg.arma.setAtaque(500);
        rg.arma.setNumMaos(1);
        rg.arma.setTipo("Lança");
        rg.setDefEscudo(400);
        rg.setMontaria(true);

        // Algoz
        Algoz sinx = new Algoz();
        sinx.nome = "Guilhotine Cross";
        sinx.nivel = 99;
        sinx.HP = 700;
        sinx.SP = 350;
        sinx.arma.setAtaque(530);
        sinx.arma.setNumMaos(2);
        sinx.arma.setTipo("Katar");
        sinx.setTipoVeneno(2);

        // Justiceiro
        Justiceiro guns = new Justiceiro();
        guns.nome = "Rebelion";
        guns.nivel = 78;
        guns.HP = 445;
        guns.SP = 32;
        guns.arma.setAtaque(800);
        guns.arma.setNumMaos(2);
        guns.arma.setTipo("AWP");
        guns.setAlcance(500);
        guns.setNumBalas(10);

        // Criando um grupo
        Grupo pt = new Grupo();

        // Armazenando os personagens no grupo
        pt.addPersonagem(hw);
        pt.addPersonagem(rg);
        pt.addPersonagem(sinx);
        pt.addPersonagem(guns);

        // Listando as informações (Printando todos os métodos dentro do listarPersonagens)
        pt.listarPersonagens();
    }
}
