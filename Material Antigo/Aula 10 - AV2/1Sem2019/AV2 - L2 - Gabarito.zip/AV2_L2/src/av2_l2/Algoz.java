package av2_l2;

/**
 * Classe Algoz, filha de Personagem, que implementa a interface DanoEmAlvo
 * @author Samuel
 */
public class Algoz extends Personagem implements DanoEmAlvo{

    // Atributos
    private int tipoVeneno;
    
    // Método específico da classe
    public void furtividade(){
        System.out.println("Furtividade !!");
    }
    
    // Método da interface
    @Override
    public void usarArma() {
        System.out.println("Atacando fisicamente com " + arma.getTipo());
    }
    
    // Sobrescrevendo o método infoPersonagem
    @Override
    public void infoPersonagem(){
        // Chamando o método já pronto da classe mãe para poupar código
        super.infoPersonagem();
        // Incrementando o metodo com os atributos de Algoz
        System.out.println("Tipo do veneno: " + this.tipoVeneno);
    }
    
    // Getters e Setters
    public int getTipoVeneno() {
        return tipoVeneno;
    }

    public void setTipoVeneno(int tipoVeneno) {
        this.tipoVeneno = tipoVeneno;
    }
    
}
