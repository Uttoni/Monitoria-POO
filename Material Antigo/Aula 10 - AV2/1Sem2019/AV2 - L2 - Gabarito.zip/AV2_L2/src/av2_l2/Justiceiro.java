package av2_l2;

/**
 * Classe Justiceiro, filha de Personagem, que implementa a interface DanoEmAlvo
 * @author Samuel
 */
public class Justiceiro extends Personagem implements DanoEmAlvo {
    
    // Atributos
    private int alcance;
    private int numBalas;
    
    // Método específico da classe
    public void rastrearAlvo(){
        System.out.println("Rastreando o Alvo ... ");
    }

    // Método da interface
    @Override
    public void usarArma() {
        System.out.println("Atirando com " + arma.getTipo() + " !!");
        this.numBalas--;
    }
    
    // Sobrescrevendo o método infoPersonagem
    @Override
    public void infoPersonagem(){
        // Chamando o método já criado da classe mãe para poupar código
        super.infoPersonagem();
        // Adicionando os atributos da classe Justiceiro
        System.out.println("Alcance: " + this.alcance + " metros");
        System.out.println("Número de balas restantes: " + this.numBalas);
    }
    
    // Getters e setters
    public int getAlcance() {
        return alcance;
    }

    public void setAlcance(int alcance) {
        this.alcance = alcance;
    }

    public int getNumBalas() {
        return numBalas;
    }

    public void setNumBalas(int numBalas) {
        this.numBalas = numBalas;
    }
    
   
}
