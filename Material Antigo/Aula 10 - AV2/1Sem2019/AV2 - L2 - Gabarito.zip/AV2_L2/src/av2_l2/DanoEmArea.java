package av2_l2;

/**
 * Interface contendo o método abstrato DanoEmArea
 * @author Samuel
 */
public interface DanoEmArea {
    
    public void usarMagia();
    
}
