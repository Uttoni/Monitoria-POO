package av2_l1;

/**
 * AV2 - Tema: Final Fantasy Tactics
 * @author Samuel
 */
public class AV2_L1 {

    public static void main(String[] args) {
        
        // *** Criando os Personagens para salvar no Array ***
        
        // *** Preenchendo os Atributos ***
        // Mage
        Mage mago = new Mage();         /* Criando um Objeto do tipo Mage */
        
        mago.nome = "Augostine";        /* Atributos da Classe Mãe (Herdados) */
        mago.signo = "Touro";           /* Atributos da Classe Mãe (Herdados) */
        mago.HP = 100;                  /* Atributos da Classe Mãe (Herdados) */
        mago.MP = 350;                  /* Atributos da Classe Mãe (Herdados) */
        mago.arma.setTipo("Cajado");    /* Atributos da Arma do Mago */
        mago.arma.setNumMaos(1);        /* Atributos da Arma do Mago */
        mago.arma.setAtaque(25);        /* Atributos da Arma do Mago */
        mago.setEspecialidade("Fogo");  /* Atributos da Classe Mago */
        
        // Monk
        Monk monge = new Monk();
        
        monge.nome = "Delita";
        monge.signo = "Escorpiao";
        monge.HP = 500;
        monge.MP = 250;
        monge.arma.setTipo("Maça");
        monge.arma.setNumMaos(2);
        monge.arma.setAtaque(300);
        monge.setForca(999);
        
        // Archer 
        Archer arqueiro = new Archer();
        
        arqueiro.nome = "Ramza";
        arqueiro.signo = "Áries";
        arqueiro.HP = 50;
        arqueiro.MP = 250;
        arqueiro.arma.setNumMaos(2);
        arqueiro.arma.setTipo("Arco");
        arqueiro.arma.setAtaque(150);
        arqueiro.setTipoArco("Arco élfico");
        arqueiro.setNumFlechas(1000);
        
        // Criando um time para armazendar os Personagens
        Team meuTime = new Team();
        
        // Adicionando os Personagens no meuTime
        meuTime.addPersonagem(mago);
        meuTime.addPersonagem(monge);
        meuTime.addPersonagem(arqueiro);
        
        // Listagem dos Personagens (chamando todos os métodos dentro de listarPersonagens)
        meuTime.listarPersonagens();
               
    }
    
}
