package av2_l1;

/**
 * Classe Arma, contida dentro da classe Personagem para deter o tipo e número de mãos que uma arma possui
 * @author Samuel
 */
class Arma {
    // Atributos da arma
    private String tipo;
    private int numMaos;
    private int ataque;

    // Getters e Setters
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getNumMaos() {
        return numMaos;
    }

    public void setNumMaos(int numMaos) {
        this.numMaos = numMaos;
    }
    
    public int getAtaque() {
        return ataque;
    }

    public void setAtaque(int ataque) {
        this.ataque = ataque;
    }
}
