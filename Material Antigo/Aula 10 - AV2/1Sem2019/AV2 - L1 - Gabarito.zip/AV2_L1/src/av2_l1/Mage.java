package av2_l1;

/**
 * Classe Mage é filha de Personagem e implementa os métodos de AtaqueMagico
 * @author Samuel
 */
public class Mage extends Personagem implements AtaqueMagico{
    
    private String especialidade;
    
    // Método único da classe 
    public void artesMagicas(){
        System.out.println("Okus Pokus !");
    }

    // Sobrescrevendo o método mostraInfo
    @Override
    public void mostraInfo() {
        // Chamando o método pronto da classe mãe
        super.mostraInfo();
        // Incrementando com os atributos específicos da classe Mage
        System.out.println("Especialidade: " + especialidade);
    }

    // Sobrescrevendo o método abstrato da interface
    @Override
    public void atacarMagia() {
        System.out.println( "Especialidade " + this.especialidade + ": usando magia !!");
    }

    // Getters e Setters
    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }
    
    
}
