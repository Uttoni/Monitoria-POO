package av2_l1;

/**
 * Classe Archer é filha de Personagem e usa a interface AtaqueFisico
 * @author Samuel
 */
public class Archer extends Personagem implements AtaqueFisico{
    
    private int numFlechas;
    private String tipoArco;
    
    // Método único da classe Archer
    public void artesPrecisas(){
        System.out.println("HeadShot");
    }
    
    // Sobrescrevendo o método para mostrar as informações da classe
    @Override
    public void mostraInfo(){
        // Chamando o método já pronto direto da classe mãe através do super
        super.mostraInfo();
        // Complementando com as informações específicas da classe Archer
        System.out.println("Numero de Flechas restantes: " + this.numFlechas);
        System.out.println("Tipo do arco: " + this.tipoArco);
    }

    // Métodos abstratos (Interface)
    @Override
    public void atacarArma() {
        System.out.println("Atirando flechas !");
        // Consome uma unidade de flecha
        System.out.println("Flechas Restantes: " + this.numFlechas --);
    }

    // Getters e Setters
    public int getNumFlechas() {
        return numFlechas;
    }

    public void setNumFlechas(int numFlechas) {
        this.numFlechas = numFlechas;
    }

    public String getTipoArco() {
        return tipoArco;
    }

    public void setTipoArco(String tipoArco) {
        this.tipoArco = tipoArco;
    }
    
    
}
