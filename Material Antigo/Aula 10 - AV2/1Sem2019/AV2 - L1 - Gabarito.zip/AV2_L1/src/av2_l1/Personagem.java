package av2_l1;

/**
 * Classe mãe
 * @author Samuel
 */
public abstract class Personagem {
    
    // Variável para contagem de personagens
    public static int contador = 0;
    
    // Atributos do meu Personagem
    protected String nome;
    protected String signo;
    protected int HP;
    protected int MP;
    
    // Não se deve instanciar esta classe no construtor, pois a classe Personagem é abstrata
    // Portanto não vamos instancia-la e consequentemente não vamos chamar o construtor !
    protected Arma arma = new Arma();

    // Métodos
    public void usarItens(){
        System.out.println("Usando itens !");
    }
    
    public void curar(){
        // Curando o HP (pontos de vida)
        System.out.println("Curando HP !");
        this.HP += 10;
    }
    
    // Escrevendo o método mostraInfo para poupar código nas classes filhas
    public void mostraInfo(){
        System.out.println("Nome: " + this.nome);
        System.out.println("Signo: " + this.signo);
        System.out.println("HP: " + this.HP);
        System.out.println("MP: " + this.MP);
        System.out.println("Tipo Arma: " + this.arma.getTipo());
        System.out.println("Numero de maõs da arma: " + this.arma.getNumMaos() );
    }
    
}
