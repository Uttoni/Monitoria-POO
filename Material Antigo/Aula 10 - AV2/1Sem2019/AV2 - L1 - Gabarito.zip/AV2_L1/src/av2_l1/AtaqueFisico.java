package av2_l1;

/**
 * Interface contendo o método abstrato atacarArma, implementando por personagens que atacam de perto
 * @author Samuel
 */
public interface AtaqueFisico {
    
    public void atacarArma();
    
}
