package av2_l1;

/**
 * Interface contendo o método abstrato atacarMagia, implementando por personagens que atacam com mágica
 * @author Samuel
 */
public interface AtaqueMagico {
    
    public void atacarMagia();
    
}
