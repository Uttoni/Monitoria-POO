package av2_l1;

/**
 * Classe Monk que é filha de Personagem e implementa as interfaces AtaqueFisico e AtaqueMagico
 * @author Samuel
 */
public class Monk extends Personagem implements AtaqueFisico, AtaqueMagico{
    
    private int forca;
    
    // Método específico da Classe
    public void artesMarciais(){
        System.out.println("Manjador dos Paranaue !");
    }
    
    // Sobrescrita do metodo mostraInfo
    @Override
    public void mostraInfo(){
        // Chamando o método pronto da classe mãe
        super.mostraInfo();
        // Incrementando com os atributos específicos da classe Mage
        System.out.println("Força: " + this.forca);
    }

    // Reescrevendo os métodos da interface
    @Override
    public void atacarArma() {
        System.out.println("Atacando com a " + arma.getTipo() + " !");
    }

    @Override
    public void atacarMagia() {
        System.out.println("Atacando com magia !");
    }
    
    // Getters e Setters
    public int getForca() {
        return forca;
    }

    public void setForca(int forca) {
        this.forca = forca;
    }
}
