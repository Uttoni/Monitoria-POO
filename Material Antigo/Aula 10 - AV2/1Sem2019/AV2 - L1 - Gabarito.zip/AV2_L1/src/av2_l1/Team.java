package av2_l1;

/**
 *
 * @author Samuel
 */
public class Team {

    // Array de Personagens, com tamanho pré definido
    private Personagem exercito[] = new Personagem[10];

    // Método para adicionar Personagem dentro do array
    public void addPersonagem(Personagem novoPersonagem) {
        // Percorrendo o array, verificando se existe uma posição vazia (null)
        for (int i = 0; i < exercito.length; i++) {
            // Verifica se a posição do array está null
            if (exercito[i] == null) {
                // Se estiver salva no array
                exercito[i] = novoPersonagem;
                // Incremento da variável contador
                Personagem.contador++;

                // Necessário para sair do for !! Se já salvou no array não tem por que continuar percorrendo o array.
                // Caso não use o break, você irá preencher completamente o array com o objeto novoPersonagem!!
                break;
            }
        }
    }

    // Listagem de personagens, mostrando seus atributos e métodos específicos
    public void listarPersonagens() {

        // Variaveis Auxiliares

        // Percorre o array de Personagens
        for (int j = 0; j < exercito.length; j++) {
            // Verifica qual é a classe da posição i
            if (exercito[j] instanceof Mage) {
                // Se for Mage cai aqui

                // Atribuo o valor do array para a variável auxiliar
                Mage mago = (Mage) exercito[j];
                
                // Chamando os métodos
                mago.usarItens();
                mago.curar();
                mago.artesMagicas();
                mago.atacarMagia();
                mago.mostraInfo();
                
                System.out.println("*********************");
            }
            if (exercito[j] instanceof Monk) {
                // Se for Monk cai aqui

                // Variável auxiliar recebe o array
                Monk monge = (Monk) exercito[j];
                
                // Chamando os Métodos
                monge.curar();
                monge.usarItens();
                monge.artesMarciais();
                monge.atacarArma();
                monge.mostraInfo();
                
                System.out.println("*********************");
            }

            if (exercito[j] instanceof Archer) {
                // Se for Archer cai aqui

                // Variável auxiliar recebe o array
                Archer arqueiro = (Archer) exercito[j];
                
                // Chamando os métodos
                arqueiro.curar();
                arqueiro.usarItens();
                arqueiro.artesPrecisas();
                arqueiro.atacarArma();
                arqueiro.mostraInfo();
                
                System.out.println("*********************");
            }
        }
        // Mostra o número final de personagens salvo no array
        System.out.println("Numero total de Personagens: " + Personagem.contador);
    }

}
